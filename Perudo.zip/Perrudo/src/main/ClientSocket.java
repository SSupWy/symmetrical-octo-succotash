package main;

import java.io.*;
import java.net.*;

public class ClientSocket {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 1234);

            // Get the input and output streams for the socket
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();

            // Wrap the streams with BufferedReader and PrintWriter for easier communication
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            PrintWriter writer = new PrintWriter(outputStream, true);

            // Main game loop
            while (true) {
                // Invio scommessa al server
                String bid = Perudo.currentBet[0] + " " + Perudo.currentBet[1] ;
                writer.println(bid);

                String serverResponse = reader.readLine();
                System.out.println("Server Response: " + serverResponse);

                // TODO controllare quando la partita finisce
                if (serverResponse.equals("Game Over")) {
                    System.out.println("Game Over. Exiting...");
                    break; // Exit the loop when the game is over
                }

                
            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
