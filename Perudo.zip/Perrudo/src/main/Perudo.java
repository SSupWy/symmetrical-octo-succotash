package main;

import java.util.ArrayList;

public class Perudo {
    private ArrayList<Player> players;
    private int[] currentBet;
    private Player currentPlayer;


    public Perudo() {
        players = new ArrayList<>();
        currentBet = new int[2];
        currentPlayer = null;
    }

    // Method to go to the next player
    public void nextPlayer() {
        int currentPlayerIndex = players.indexOf(currentPlayer);
        int nextPlayerIndex = (currentPlayerIndex + 1) % players.size();
        currentPlayer = players.get(nextPlayerIndex);
    }
    
    public void setCurrentPlayerToNextPlayer(){
        int playerIndex = players.indexOf(currentPlayer);
        int nextPlayerIndex;
//        If end of the list, go back to first player
        if (players.size() == (playerIndex + 1)){
            nextPlayerIndex = 0;
        } else {
            nextPlayerIndex = playerIndex + 1;
        }
        this.currentPlayer = players.get(nextPlayerIndex);
    }

    // Method to get the current bet
    public int[] getCurrentBet() {
        return currentBet;
    }

    // Method to make a new bet
    public void makeNewBet(int numberOfDice, int diceValue) {
        // Controllo se la quantità e valore sono validi
        if (numberOfDice > 0 && diceValue >= 1 && diceValue <= 6) {
            // Aggiorna la bet corrente
            currentBet[0] = numberOfDice;
            currentBet[1] = diceValue;
            
            // Stampa la nuova bet
            System.out.println(currentPlayer.getName()+ "Sta scommettendo: " + numberOfDice + " " + diceValue);

        } else {
            System.out.println("bet invalida"); // Se la bet non è valida
        }

    }

    // Metodo per calcolare se la bet è corretta
    public void isBetCorrect(int numberOfDice, int diceValue) { //boolean
        boolean X;
    	int count = 0;
        for (Player player : players) {
            count += player.getNumberOfDiceWithValue(diceValue);
        }
        // TODO return count >= numberOfDice;

        // Prendo le info della bet corrente
        int numOfDiceBet = currentBet[0];
        int dieValue = currentBet[1];
        System.out.println("Scommessa per: "+ numOfDiceBet +" "+ dieValue);
        // Svela i dadi presenti
        System.out.println("Ci sono: -  dadi di valore"+ dieValue ); 
        //   TODO return numOfDiceResult >= numOfDiceBet;
    }

    //Metodo per ottenere il giocatore precedente
    public Player getPreviousPlayer() {
        int currentPlayerIndex = players.indexOf(currentPlayer);
        int previousPlayerIndex = (currentPlayerIndex - 1 + players.size()) % players.size();
        return players.get(previousPlayerIndex);
    }

    
    public Player revealDice() {
    //Rivelazione dei dadi
    System.out.println(currentPlayer.getName()+ "Vuole rivelare i dadi");
    //Calcolo il numero di dadi effettivi
    calculateActualNumberOfDie();
    //Controllo se la bet è corretta
    boolean betIsCorrect = true; // TODO boolean betIsCorrect = IsBetCorrect();
    int loserIndex;
    Player loser;
    //Se la bet è corretta, il giocatore precedente perde un dado
    if(betIsCorrect){
        loser = this.currentPlayer;
        System.out.println(getPreviousPlayer().getName() + " La scommessa era corretta.");

    } else {
        loser = getPreviousPlayer();
        System.out.println(getPreviousPlayer().getName() + " Stava mentendo.");
    }
    //Rimuovo un dado al loser
    loserIndex = this.players.indexOf(loser);
    this.removeADie(loser); //TODO implementare rimuovere un dado ad uno specifico giocatore
    if (this.isRunning){
        if (loserIndex == this.players.size()){
            loserIndex --;
        }
        this.setCurrentPlayer(loserIndex);
        // Resetta il game
        this.isfirstRound = true;
    }
    return loser;
}
public void calculateActualNumberOfDie(){
    int dieValue = currentBet[1];
    int numOfDiceResult = 0;
    for(Player player: players){
        ArrayList<Dice> diceValues = player.getDiceValues();
        System.out.println(player.getName()+ " aveva: "+ diceValues.toString());
        for (Dice die : diceValues){
            if (die.getValue() == dieValue){
                numOfDiceResult ++;
            }

            if(dieValue != 1 && die.getValue() ==1){
                numOfDiceResult ++;
            }
        }

    }
    setNumOfDiceResult(numOfDiceResult);
}
}