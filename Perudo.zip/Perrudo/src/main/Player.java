package main;

import java.util.ArrayList;
import java.util.Collections;

public class Player {
    private String name;
    private ArrayList<Integer> diceValues;

    public Player(String name) {
        this.name = name;
        this.diceValues = new ArrayList<>();
        shuffleDice();
    }

    public String getName() {
        return name;
    }

    public ArrayList<Integer> getDiceValues() {
        return diceValues;
    }

    public void shuffleDice() {
        diceValues.clear();
        for (int i = 0; i < 5; i++) {
            diceValues.add((int) (Math.random() * 6) + 1);
        }
    }

    public void loseADie() {
        if (!diceValues.isEmpty()) {
            diceValues.remove(diceValues.size() - 1);
        }
    }

	public int getNumberOfDiceWithValue(int diceValue) {
		// TODO logica
		return 0;
	}
}
