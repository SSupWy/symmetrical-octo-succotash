package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSockett {
    public static void main(String[] args) {
        int port = 1234;
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server su porta " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connesso: "); //TODO + clientSocket.getInetAddress().getHostAddress()

                // Gestire la comunicazione con il client in un thread separato
                Thread clientThread = new Thread(new ClientHandler(clientSocket));
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ClientHandler implements Runnable {
    private Socket clientSocket;

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try {
            // Input e output per comunicare con il client
            InputStream inputStream = clientSocket.getInputStream();
            OutputStream outputStream = clientSocket.getOutputStream();

            // Use the input and output streams to send/receive data with the client

            // TODO logica communicazione
            // Leggere dal client
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String clientData = reader.readLine();
            System.out.println("Dato ricevuto: " + clientData);

            // Inviare al client
            PrintWriter writer = new PrintWriter(outputStream);
            writer.println("Invio al client");
            writer.flush();

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
}
